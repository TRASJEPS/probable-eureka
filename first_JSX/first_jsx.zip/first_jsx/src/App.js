import './App.css';
import List from './components/List';

function App() {
  return (
    <header className="App-header">
    <div className="App">
      <h1>Hello Dojo!</h1>
      <List />
    </div>
    
    </header>

    

    

  );
}

export default App;
